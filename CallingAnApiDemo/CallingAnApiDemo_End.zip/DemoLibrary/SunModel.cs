﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoLibrary
{
    public class SunModel
    {
        public DateTime Sunrise { get; set; }
        public DateTime Sunset { get; set; }
    }
}
