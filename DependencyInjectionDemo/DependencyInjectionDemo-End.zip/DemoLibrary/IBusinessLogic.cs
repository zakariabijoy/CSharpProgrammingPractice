﻿namespace DemoLibrary
{
    public interface IBusinessLogic
    {
        void ProcessData();
    }
}