﻿using MQTTnet;
using MQTTnet.Client;
using MQTTnet.Protocol;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;

var mqttFactory = new MqttFactory();
var client  = mqttFactory.CreateMqttClient();

#region with out tsl
//var options = new MqttClientOptionsBuilder()
//                .WithClientId(Guid.NewGuid().ToString())
//                .WithTcpServer("localhost", 1883)
//                .WithCleanSession()
//                .Build();

#endregion

#region with tsl
var tslOption = new MqttClientOptionsBuilderTlsParameters
{
    UseTls = true,
    Certificates = new List<X509Certificate>
    {
        new X509Certificate("broker.emqx.io-ca.crt")
    },
    AllowUntrustedCertificates = true,
    IgnoreCertificateChainErrors = true,
    IgnoreCertificateRevocationErrors = true,
};

var options = new MqttClientOptionsBuilder()
                .WithClientId(Guid.NewGuid().ToString())
                .WithTcpServer("broker.emqx.io", 8883)
                .WithTls(tslOption)
                .WithCleanSession()
                .Build();
#endregion


client.ConnectedAsync += Client_ConnectedAsync;
client.DisconnectedAsync += Client_DisconnectedAsync;

await client.ConnectAsync(options);

Console.WriteLine("Please press a key to publish the message");
Console.ReadLine();

await PublishMessageAsync(client);
await client.DisconnectAsync();

async Task PublishMessageAsync(IMqttClient client)
{
    string messagePayload = "Hello from dotnet 6 console publisher project";

    #region with out encryption
    //var message = new MqttApplicationMessageBuilder()
    //               .WithTopic("testtopic/csharp/zakaria")
    //               .WithPayload(messagePayload)
    //               .WithQualityOfServiceLevel(MqttQualityOfServiceLevel.ExactlyOnce)
    //               .Build();
    #endregion

    #region with encryption
    var message = new MqttApplicationMessageBuilder()
                        .WithTopic("testtopic/csharp/zakaria")
                        .WithPayload(EncryptMessage(messagePayload, "7X6SO5W9LJPVT8ZA01U3QBEKG2DR4HMY"))
                        .WithQualityOfServiceLevel(MqttQualityOfServiceLevel.ExactlyOnce)
                        .Build();
    #endregion

    if (client.IsConnected)
    {
        await client.PublishAsync(message);
        Console.WriteLine("Message published to broker successfully");
    }
         
}

string EncryptMessage(string payload, string encryptionKey )
{
    var key = Encoding.UTF8.GetBytes(encryptionKey);
    using (var aesAlgo = Aes.Create())
    {
        aesAlgo.Padding = PaddingMode.Zeros;
        using (var encryptor = aesAlgo.CreateEncryptor(key, aesAlgo.IV))
        {
            using (var memoryStream = new MemoryStream())
            {
                using (var cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
                {
                    using (var streamWrite =  new StreamWriter(cryptoStream))
                    {
                        streamWrite.Write(payload);
                    }
                    var initializationVector = aesAlgo.IV;
                    var encryptedContent = memoryStream.ToArray();
                    var result = new byte[initializationVector.Length + encryptedContent.Length];
                    Buffer.BlockCopy(initializationVector, 0, result, 0, initializationVector.Length);
                    Buffer.BlockCopy(encryptedContent, 0, result, initializationVector.Length, encryptedContent.Length);
                    return Convert.ToBase64String(result);
                }
            }
        }
    }
}

Task Client_ConnectedAsync(MqttClientConnectedEventArgs arg)
{
    Console.WriteLine("MQTT publisher is connected to the broker successfully");
    return Task.CompletedTask;
}

Task Client_DisconnectedAsync(MqttClientDisconnectedEventArgs arg)
{
    Console.WriteLine("MQTT publisher is disconnected from the broker successfully");
    return Task.CompletedTask;
}
