﻿using MQTTnet.Client;
using MQTTnet;
using System.Text;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography;

var mqttFactory = new MqttFactory();
var client = mqttFactory.CreateMqttClient();

#region with out tls
//var options = new MqttClientOptionsBuilder()
//        .WithClientId(Guid.NewGuid().ToString())
//        .WithTcpServer("localhost", 1883)
//        .WithCleanSession()
//        .Build();
#endregion

#region with tsl
var tslOption = new MqttClientOptionsBuilderTlsParameters
{
    UseTls = true,
    Certificates = new List<X509Certificate>
    {
        new X509Certificate("broker.emqx.io-ca.crt")
    },
    AllowUntrustedCertificates = true,
    IgnoreCertificateChainErrors = true,
    IgnoreCertificateRevocationErrors = true,
};

var options = new MqttClientOptionsBuilder()
                .WithClientId(Guid.NewGuid().ToString())
                .WithTcpServer("broker.emqx.io", 8883)
                .WithTls(tslOption)
                .WithCleanSession()
                .Build();
#endregion

client.ConnectedAsync += Client_ConnectedAsync;
client.DisconnectedAsync += Client_DisconnectedAsync;
client.ApplicationMessageReceivedAsync += Client_ApplicationMessageReceivedAsync;


await client.ConnectAsync(options);

Console.ReadLine();

await client.DisconnectAsync();


async Task Client_ConnectedAsync(MqttClientConnectedEventArgs arg)
{
    Console.WriteLine("MQTT subscriber 2 is connected to the broker successfully");
    var topicFilter = new MqttTopicFilterBuilder()
                        .WithTopic("testtopic/csharp/zakaria")
                        .Build();
    await client.SubscribeAsync(topicFilter);
}

Task Client_ApplicationMessageReceivedAsync(MqttApplicationMessageReceivedEventArgs arg)
{
    Console.WriteLine($"Encrypted Received Message - {Encoding.UTF8.GetString(arg.ApplicationMessage.Payload)}");
    Console.WriteLine($"Received Message - {DecryptString(Encoding.UTF8.GetString(arg.ApplicationMessage.Payload), $"{"7X6SO5W9LJPVT8ZA01U3QBEKG2DR4HMY"}")}");
    return Task.CompletedTask;
}

string DecryptString(string encryptedMessage, string encryptionKey)
{
    var fullCipher = Convert.FromBase64String(encryptedMessage);
    var cipher = new byte[fullCipher.Length - 16];
    var initializatioVector = new byte[16];
    Buffer.BlockCopy(fullCipher, 0, initializatioVector, 0, initializatioVector.Length);
    Buffer.BlockCopy(fullCipher, initializatioVector.Length, cipher, 0, cipher.Length);

    var key = Encoding.UTF8.GetBytes(encryptionKey);

    using (var aesAlgo = Aes.Create())
    {
        aesAlgo.Padding = PaddingMode.Zeros;
        using (var decryptor = aesAlgo.CreateDecryptor(key, initializatioVector))
        {
            string result;
            using (var memoryStream = new MemoryStream(cipher))
            {
                using (var cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read))
                {
                    using (var streamReader = new StreamReader(cryptoStream))
                    {
                        result = streamReader.ReadToEnd();
                    }
                }
            }
            return result;
        }
    }
}

Task Client_DisconnectedAsync(MqttClientDisconnectedEventArgs arg)
{
    Console.WriteLine("MQTT subscriber 2 is disconnected from the broker successfully");
    return Task.CompletedTask;
}
