﻿using Microsoft.Extensions.Configuration;


var environmentName = "Development"/* Environment.GetEnvironmentVariable("DotNet_ENVIRONMENT")*/;
var configBuilder  = new ConfigurationBuilder()
                    .SetBasePath(Directory.GetCurrentDirectory())
                    .AddJsonFile($"appsettings.json", true, true)
                    .AddJsonFile($"appsettings.{environmentName}.json", true, true)
                    .AddEnvironmentVariables();

// Load configurations
IConfigurationRoot configuration = configBuilder.Build();

Console.WriteLine(configuration["connectionString"]);

