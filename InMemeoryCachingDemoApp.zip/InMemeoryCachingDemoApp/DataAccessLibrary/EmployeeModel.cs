﻿namespace DataAccessLibrary
{
    public class EmployeeModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}